//Script for onclick alert text
const languageButton = document.querySelector('#language-button');
languageButton.addEventListener('click', () => {
  alert('Did you know that I once rode my bike across the entire city?');
});